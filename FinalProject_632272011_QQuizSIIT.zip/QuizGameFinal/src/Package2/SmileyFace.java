package Package2;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class SmileyFace extends JPanel{
	
	public SmileyFace(){
		this.setSize(500,500);
		this.setOpaque(false);
	}
	
	 @Override
	protected void paintComponent(Graphics g){
		super.paintComponent(g);
		drawYellowCircle(g);
		drawEye(g, 325, 200);
		drawEye(g, 175, 200);
		drawMouth(g);
	}
	
	public static void drawYellowCircle(Graphics g) {

		//Creating a yellow circle
		g.setColor(Color.YELLOW);
		g.fillOval(50, 50,400,400);
		
		//Border for the yellow circle
		g.setColor(Color.BLACK);
		g.drawOval(50, 50, 400, 400);
	}
	
	
	public static void drawEye(Graphics g, int x, int y) {
		
		//Eye size 
		int height = 100;
		int width = 50;
		
		//Drawing the eye
		g.setColor(Color.BLACK);
		g.fillOval(x - (width / 2), y - (height / 2), width, height);
	}
	
	// For the beautiful mouth
	public static void drawMouth(Graphics g) {
		g.setColor(Color.red);
		((Graphics2D) g).setStroke(new BasicStroke(4));
		g.drawArc(185, 310, 125, 20, 170, 190);
		
		
	}
	
	
	

}
