package Package2;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.ImageIcon;

public class Welcome extends JFrame implements KeyListener{
	
	//Border
	Border border = BorderFactory.createLineBorder(Color.white);
	//Panels
	JPanel panel1 = new JPanel();
	JPanel panel2 = new JPanel();
	JPanel panel3 = new JPanel();
	JPanel panel4 = new JPanel();
	
	//Label
	JLabel label1 = new JLabel("Congratulations!");
	JLabel label2 = new JLabel(" 'You have been accepted into SIIT. Please press Esc to exit.' ");
	
	//Buttons 
	JButton button1 = new JButton("Yes, I would love to enroll");
	JButton button2 = new JButton("No, I am not interested");
	JButton button3 = new JButton("Let me think about it");
	
	public Welcome(){
		super("Welcome to SIIT");
		this.setLayout(new GridLayout(4,1));
		addKeyListener(this);
		setFocusable(true);
		
		//Panel 
		panel1.setBackground(Color.white);
		panel3.setBorder(border);
		panel1.setSize(120,120);
		//Labels
		ImageIcon image1 = new ImageIcon(getClass().getResource("/new.png"));
		JLabel label3 = new JLabel(image1);
		label3.setOpaque(false);
		label1.setHorizontalTextPosition(JLabel.CENTER);
		label1.setVerticalTextPosition(JLabel.CENTER);
		label1.setFont(new Font("Open Sans", Font.BOLD, 60));
		label2.setFont(new Font("Libre Baskerville", Font.ITALIC,20));
		
		button1.setFont(new Font("Libre Baskerville", Font.PLAIN, 18));
		button2.setFont(new Font("Libre Baskerville", Font.PLAIN, 18));
		button3.setFont(new Font("Libre Baskerville", Font.PLAIN, 18));
		panel4.setLayout(new FlowLayout());
		

	
		
		panel1.add(label3);
		panel2.add(label1);
		panel3.add(label2);
		panel4.add(button1);
		panel4.add(button2);
		panel4.add(button3);

		this.add(panel1);
		this.add(panel2);
		this.add(panel3);
		this.add(panel4);
		this.getContentPane().setBackground(Color.white);
		this.setResizable(false);
		this.setSize(650,690);
		this.setVisible(true);
		
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent f) {
		// TODO Auto-generated method stub
		if(f.getKeyCode() == KeyEvent.VK_ESCAPE){
			System.exit(0);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
