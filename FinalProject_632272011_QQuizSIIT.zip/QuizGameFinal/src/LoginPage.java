import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Package2.Quiz;
import Package2.SmileyFace;



public class LoginPage extends IDandPasswords implements ActionListener {
	JFrame frame = new JFrame();
	JButton loginButton = new JButton("Login");
	JButton resetButton = new JButton("Reset");
	JTextField userIDField = new JTextField(); 
	JPasswordField userPasswordField = new JPasswordField();
	JLabel userIDLabel = new JLabel("userID: ");
	JLabel userPasswordLabel = new JLabel("Password: ");
	JLabel messageLabel = new JLabel();
	SmileyFace face = new SmileyFace();
	HashMap<String,String> logininfo = new HashMap<String,String>();
	
	
	LoginPage(HashMap<String,String>loginInfoOriginal){
		logininfo = loginInfoOriginal;
		
		userIDLabel.setBounds(50,100,75, 25);
		userPasswordLabel.setBounds(50,150,75, 25);
		
		messageLabel.setBounds(125,250,250,35);
		messageLabel.setFont(new Font(null,Font.ITALIC,25));
		
		//Where someone is going to type their USER and Password
		userIDField.setBounds(125,100,200,25);
		userPasswordField.setBounds(125,150,200,25);
		//Buttons
		loginButton.setBounds(125,200,100,25);
		loginButton.addActionListener(this);
		
		
		resetButton.setBounds(225,200,100,25);
		resetButton.addActionListener(this);
		
		
		ImageIcon imgicon = new ImageIcon(getClass().getResource("/SIITLOGO.jpg"));
        frame.setIconImage(imgicon.getImage());
		
		//if the order to which we add to the frames is not in a certain order, then we would have problems? 
		frame.add(userIDLabel);
		frame.add(userPasswordLabel);
		frame.add(messageLabel);
		
		frame.add(userIDField);
		frame.add(userPasswordField);
		
		frame.add(loginButton);
		frame.add(resetButton);
		
		frame.add(face);
		frame.setTitle("Login");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(420,420);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setVisible(true);
		
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		//clears the textfield if login and reset are pressed
		if(e.getSource()==resetButton) {
			userIDField.setText("");
			userPasswordField.setText("");
		}
		// get the string for what we typed and then we stored it into the userID and password variables
		if(e.getSource() == loginButton) {
			String userID = userIDField.getText();
			String password = String.valueOf(userPasswordField.getPassword());
		
		
			if(logininfo.containsKey(userID)){
				if (logininfo.get(userID).equals(password)){
					messageLabel.setForeground(Color.blue);
					messageLabel.setText("Login Successful");
					Quiz quiz = new Quiz();
					
			}
				
				
				else {
					messageLabel.setForeground(Color.RED);
					messageLabel.setText("Invalid Password");
				}
				
				
		}
			
		else {
			messageLabel.setForeground(Color.RED);
			messageLabel.setText("Username not found");
			}
	}
		
		
		
		
		
}
	
	
	
	
}
