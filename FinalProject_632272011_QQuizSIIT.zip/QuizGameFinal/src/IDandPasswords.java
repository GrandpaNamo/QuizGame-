import java.util.HashMap;

public class IDandPasswords {

	HashMap<String,String> logininfo = new HashMap<String,String>();
	
	IDandPasswords(){
		
		logininfo.put("Phuritat","Chakreeyarat");
	}
	
	public HashMap getLoginInfo(){
		return logininfo;
	}
}